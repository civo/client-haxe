# civo (C#) v1.0.0

Generated C# sources (`-D no-compilation`). Build with `dotnet` / Mono as needed.
