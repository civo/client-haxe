# civo (PHP) v1.0.0

Haxe-compiled Civo API client. Autoload `index.php` / generated classes from this directory.
