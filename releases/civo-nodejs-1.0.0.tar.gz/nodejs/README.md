# civo (Node.js) v1.0.0

Haxe-compiled Civo API client.

```js
const { Civo } = require('./civo.js');
const civo = new Civo({ token: process.env.CIVO_API_TOKEN, region: 'LON1' });
civo.instances.list((status, body) => console.log(status, body));
```
