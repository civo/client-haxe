# civo (Java) v1.0.0

Generated Java sources. Compile with javac against a JDK; uses tink_http Std/Socket clients.
